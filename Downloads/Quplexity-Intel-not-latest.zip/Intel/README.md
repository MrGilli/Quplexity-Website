# Quplexity for x86_64bit Intel CPU's
This is the folder/directory that holds all the Quplexity code for Intel CPU's and Intel CPU'S ONLY (If your working for ARM see ../ARM).

## Guide and User Manual for Quplexity-Intel.
To get started with Quplexity-Intel please take the time to look at the carefully crafted documentation: (./Documentation/Intel_Manual.pdf).

## To Contribute:
Please don't hesitate to contact me if you wish to contribute/improve Quplexity, as well as if you have any cool ideas or questions:

Email: jacobygill@outlook.com 

Discord: @mrgill0651
