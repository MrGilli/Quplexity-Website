# Quplexity for ARM CPU's
Quplexity-ARM is still in development, I aim to make Quplexity useable even on a Raspberry Pi!
Expect to see more updates on Quplexity in the vibrant future.

Currently only some of the functions in Intel/math.asm can be found (rewritten for ARM/ARM64) in Quplexity-AMR's version: math.s 
Expect more in the future!!
